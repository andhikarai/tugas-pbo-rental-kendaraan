package com.login;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class AdminController {
    @FXML private Label txtTotal, txtMobil, txtMotor;
    @FXML private TableView<Kendaraan> tableKendaraan;
    @FXML private TableColumn<Kendaraan, Integer> colId;
    @FXML private TableColumn<Kendaraan, String> colNama, colTipe, colPlat;
    @FXML private TableColumn<Kendaraan, Double> colHarga;
    @FXML private TableColumn<Kendaraan, Boolean> colStatus; 

    private ObservableList<Kendaraan> dataList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // 1. Hubungkan Kolom
        colId.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        colNama.setCellValueFactory(cellData -> cellData.getValue().namaProperty());
        colTipe.setCellValueFactory(cellData -> cellData.getValue().tipeProperty());
        colPlat.setCellValueFactory(cellData -> cellData.getValue().platProperty());
        
        // 2. Format Harga
        colHarga.setCellValueFactory(cellData -> cellData.getValue().hargaProperty().asObject());
        colHarga.setCellFactory(tc -> new TableCell<Kendaraan, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) setText(null);
                else {
                    NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
                    setText(formatRupiah.format(price));
                }
            }
        });

        // 3. Format Status
        if (colStatus != null) {
            colStatus.setCellValueFactory(cellData -> cellData.getValue().tersediaProperty());
            colStatus.setCellFactory(tc -> new TableCell<Kendaraan, Boolean>() {
                @Override
                protected void updateItem(Boolean tersedia, boolean empty) {
                    super.updateItem(tersedia, empty);
                    if (empty || tersedia == null) {
                        setText(null);
                        setStyle("");
                    } else {
                        if (tersedia) {
                            setText("Tersedia");
                            setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                        } else {
                            setText("Disewa");
                            setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                        }
                    }
                }
            });
        }

        refreshDashboard();
    }

    private void refreshDashboard() {
        loadTableData();
        updateStats();
    }

    // --- BAGIAN INI JADI LEBIH BERSIH DENGAN DAO ---
    private void loadTableData() {
        dataList.clear();
        // Tidak ada lagi SQL disini, panggil DAO
        dataList.addAll(KendaraanDAO.getAllKendaraan());
        tableKendaraan.setItems(dataList);
    }

    private void updateStats() {
        // Tidak ada lagi SQL disini, panggil DAO
        txtTotal.setText(String.valueOf(KendaraanDAO.getJumlahTotal()));
        txtMobil.setText(String.valueOf(KendaraanDAO.getJumlahMobil()));
        txtMotor.setText(String.valueOf(KendaraanDAO.getJumlahMotor()));
    }

    @FXML
    private void handleViewDetail() throws IOException {
        App.setRoot("detail_kendaraan");
    }

    @FXML
    private void handleGoToTransaction() throws IOException {
        // Pastikan nama file fxml-nya admin_transaksi.fxml
        App.setRoot("admin_transaksi"); 
    }

    @FXML
    private void handleLogout() throws IOException {
        App.setRoot("primary");
    }
}