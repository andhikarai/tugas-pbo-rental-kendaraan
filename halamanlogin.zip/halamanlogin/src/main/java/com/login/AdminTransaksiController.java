package com.login;

import java.io.IOException;
import java.sql.SQLException;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class AdminTransaksiController {

    @FXML private TableView<TransaksiView> tableTransaksi;
    @FXML private TableColumn<TransaksiView, Integer> colId;
    @FXML private TableColumn<TransaksiView, String> colPenyewa, colKendaraan, colPlat, colMulai, colSelesai;

    @FXML
    public void initialize() {
        // Setup Kolom
        colId.setCellValueFactory(data -> data.getValue().idTransaksiProperty().asObject());
        colPenyewa.setCellValueFactory(data -> data.getValue().namaPenyewaProperty());
        colKendaraan.setCellValueFactory(data -> data.getValue().namaKendaraanProperty());
        colPlat.setCellValueFactory(data -> data.getValue().platNomorProperty());
        colMulai.setCellValueFactory(data -> data.getValue().tglMulaiProperty());
        colSelesai.setCellValueFactory(data -> data.getValue().tglSelesaiProperty());

        loadData();
    }

    private void loadData() {
        ObservableList<TransaksiView> data = TransaksiDAO.getTransaksiAktif();
        tableTransaksi.setItems(data);
    }

    @FXML
    private void handleKembali() {
        TransaksiView selected = tableTransaksi.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showAlert(AlertType.WARNING, "Pilih Data", "Silakan pilih transaksi yang ingin diproses.");
            return;
        }

        Alert confirm = new Alert(AlertType.CONFIRMATION, 
            "Konfirmasi pengembalian unit " + selected.getNamaKendaraan() + 
            " dari penyewa " + selected.getNamaPenyewa() + "?\n\nStatus kendaraan akan kembali menjadi 'Tersedia'.", 
            ButtonType.YES, ButtonType.NO);
        confirm.showAndWait();

        if (confirm.getResult() == ButtonType.YES) {
            try {
                // Panggil DAO untuk update status kendaraan jadi 1 (Tersedia)
                TransaksiDAO.terimaPengembalian(selected.getIdKendaraan());
                
                showAlert(AlertType.INFORMATION, "Sukses", "Kendaraan telah dikembalikan dan siap disewa lagi.");
                
                // Refresh tabel (Data akan hilang dari tabel ini karena statusnya sudah tersedia)
                loadData(); 

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(AlertType.ERROR, "Error", "Gagal memproses pengembalian: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleBack() throws IOException {
        App.setRoot("admin_dashboard");
    }

    private void showAlert(AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}