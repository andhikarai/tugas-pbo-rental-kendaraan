package com.login;

import java.io.IOException;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DetailController {

    // --- Sambungkan ke Komponen FXML ---
    @FXML private TextField txtSearch;
    @FXML private TableView<Kendaraan> tableDetail;
    @FXML private TableColumn<Kendaraan, Integer> colId;
    @FXML private TableColumn<Kendaraan, String> colNama, colTipe, colPlat;
    @FXML private TableColumn<Kendaraan, Double> colHarga;
    @FXML private TableColumn<Kendaraan, Boolean> colStatus;

    private ObservableList<Kendaraan> dataList = FXCollections.observableArrayList();
    private FilteredList<Kendaraan> filteredData;

    @FXML
    public void initialize() {
        // 1. Setup Kolom Tabel
        colId.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        colNama.setCellValueFactory(cellData -> cellData.getValue().namaProperty());
        colTipe.setCellValueFactory(cellData -> cellData.getValue().tipeProperty());
        colPlat.setCellValueFactory(cellData -> cellData.getValue().platProperty());

        // 2. Format Harga (Rp)
        colHarga.setCellValueFactory(cellData -> cellData.getValue().hargaProperty().asObject());
        colHarga.setCellFactory(tc -> new TableCell<Kendaraan, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
                    setText(formatRupiah.format(price));
                }
            }
        });

        // 3. Format Warna Status
        colStatus.setCellValueFactory(cellData -> cellData.getValue().tersediaProperty());
        colStatus.setCellFactory(tc -> new TableCell<Kendaraan, Boolean>() {
            @Override
            protected void updateItem(Boolean tersedia, boolean empty) {
                super.updateItem(tersedia, empty);
                if (empty || tersedia == null) {
                    setText(null);
                    setStyle("");
                } else {
                    if (tersedia) {
                        setText("Tersedia");
                        setStyle("-fx-text-fill: green; -fx-font-weight: bold;");
                    } else {
                        setText("Disewa");
                        setStyle("-fx-text-fill: red; -fx-font-weight: bold;");
                    }
                }
            }
        });

        // 4. Muat Data Awal (Sekarang pakai DAO)
        loadFullData();

        // 5. LOGIKA PENCARIAN (SEARCH)
        filteredData = new FilteredList<>(dataList, b -> true);

        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(kendaraan -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (kendaraan.getNama().toLowerCase().contains(lowerCaseFilter)) return true;
                else if (kendaraan.getTipe().toLowerCase().contains(lowerCaseFilter)) return true;
                else if (kendaraan.getPlatNomor().toLowerCase().contains(lowerCaseFilter)) return true;
                
                return false;
            });
        });

        SortedList<Kendaraan> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(tableDetail.comparatorProperty());
        tableDetail.setItems(sortedData);
    }

    // --- BAGIAN INI DIUBAH JADI DAO ---
    private void loadFullData() {
        // Ambil data dari DAO
        ObservableList<Kendaraan> dataDariDB = KendaraanDAO.getAllKendaraan();
        
        // Bersihkan list lama dan isi dengan yang baru
        dataList.clear();
        dataList.addAll(dataDariDB);
    }

    // --- BUTTON HANDLERS ---
    @FXML
    private void handleAdd() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("input_kendaraan.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Tambah Kendaraan Baru");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

            // Refresh tabel setelah form ditutup
            loadFullData(); 

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEdit() {
        Kendaraan selected = tableDetail.getSelectionModel().getSelectedItem();
        
        if (selected != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("input_kendaraan.fxml"));
                Parent root = loader.load();

                InputController controller = loader.getController();
                controller.setKendaraan(selected); // Kirim data ke form edit

                Stage stage = new Stage();
                stage.setTitle("Edit Kendaraan");
                stage.setScene(new Scene(root));
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.showAndWait();

                // Refresh tabel setelah edit selesai
                loadFullData();

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            showAlert(AlertType.WARNING, "Peringatan", "Pilih kendaraan yang ingin diedit terlebih dahulu!");
        }
    }

    @FXML
    private void handleDelete() {
        Kendaraan selected = tableDetail.getSelectionModel().getSelectedItem();
        
        if (selected != null) {
            Alert alert = new Alert(AlertType.CONFIRMATION, 
                "Yakin ingin menghapus kendaraan " + selected.getNama() + " (" + selected.getPlatNomor() + ")?", 
                ButtonType.YES, ButtonType.NO);
            alert.showAndWait();

            if (alert.getResult() == ButtonType.YES) {
                deleteData(selected);
            }
        } else {
            showAlert(AlertType.WARNING, "Peringatan", "Pilih kendaraan yang ingin dihapus terlebih dahulu!");
        }
    }

    // --- BAGIAN INI DIUBAH JADI DAO ---
    private void deleteData(Kendaraan k) {
        try {
            // Panggil DAO untuk hapus di Database
            KendaraanDAO.hapusKendaraan(k.getId());
            
            // Hapus di UI
            dataList.remove(k);
            showAlert(AlertType.INFORMATION, "Sukses", "Data berhasil dihapus.");
            
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Gagal menghapus: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() throws IOException {
        App.setRoot("admin_dashboard");
    }

    private void showAlert(AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}