package com.login;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
// Import java.sql.Connection tidak diperlukan lagi
// Cukup import Exception atau SQLException jika perlu spesifik

public class InputController {

    @FXML private TextField txtNama;
    @FXML private ComboBox<String> cmbTipe;
    @FXML private TextField txtPlat;
    @FXML private TextField txtHarga;
    @FXML private Label lblJudul; 

    private Kendaraan kendaraanEdit; 
    private boolean isEditMode = false; 

    @FXML
    public void initialize() {
        cmbTipe.getItems().addAll("Mobil", "Motor");
    }

    // --- Menerima Data dari DetailController (Tidak Berubah) ---
    public void setKendaraan(Kendaraan k) {
        this.kendaraanEdit = k;
        this.isEditMode = true;

        txtNama.setText(k.getNama());
        cmbTipe.setValue(k.getTipe());
        txtPlat.setText(k.getPlatNomor());
        txtHarga.setText(String.valueOf((long)k.getHargaPerHari())); 
    }

    @FXML
    private void handleSave() {
        if (isInputValid()) {
            saveToDatabase();
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean isInputValid() {
        String errorMsg = "";
        if (txtNama.getText().isEmpty()) errorMsg += "Nama belum diisi!\n";
        if (cmbTipe.getValue() == null) errorMsg += "Tipe belum dipilih!\n";
        if (txtPlat.getText().isEmpty()) errorMsg += "Plat Nomor belum diisi!\n";
        if (txtHarga.getText().isEmpty()) errorMsg += "Harga belum diisi!\n";

        if (!errorMsg.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Validasi Error");
            alert.setContentText(errorMsg);
            alert.showAndWait();
            return false;
        }
        return true;
    }

    // --- BAGIAN INI YANG DIUBAH MENJADI DAO ---
    private void saveToDatabase() {
        try {
            // 1. Siapkan data ID dan Status
            int id = isEditMode ? kendaraanEdit.getId() : 0; // Jika edit pakai ID lama, jika baru 0
            boolean status = isEditMode ? kendaraanEdit.isTersedia() : true; // Jika edit pertahankan status, jika baru default tersedia

            // 2. Buat objek Kendaraan baru dari input form
            Kendaraan kBaru = new Kendaraan(
                id,
                txtNama.getText(),
                cmbTipe.getValue(),
                txtPlat.getText(),
                Double.parseDouble(txtHarga.getText()),
                status
            );

            // 3. Panggil DAO (Tukang Database)
            if (isEditMode) {
                KendaraanDAO.updateKendaraan(kBaru); // Panggil fungsi Update di DAO
            } else {
                KendaraanDAO.tambahKendaraan(kBaru); // Panggil fungsi Tambah di DAO
            }

            // 4. Jika tidak ada error, tampilkan sukses
            showAlert("Sukses", "Data Berhasil Disimpan!");
            closeWindow();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Gagal menyimpan: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) txtNama.getScene().getWindow();
        stage.close();
    }
}