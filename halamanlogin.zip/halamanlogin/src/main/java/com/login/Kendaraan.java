package com.login;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Kendaraan {
    private final IntegerProperty id_kendaraan;
    private final StringProperty nama;
    private final StringProperty tipe;
    private final StringProperty platNomor;
    private final DoubleProperty hargaPerHari;
    private final BooleanProperty tersedia; 

    // Constructor dengan 6 parameter sesuai struktur DB terbaru
    public Kendaraan(int id, String nama, String tipe, String plat, double harga, boolean tersedia) {
        this.id_kendaraan = new SimpleIntegerProperty(id);
        this.nama = new SimpleStringProperty(nama);
        this.tipe = new SimpleStringProperty(tipe);
        this.platNomor = new SimpleStringProperty(plat);
        this.hargaPerHari = new SimpleDoubleProperty(harga);
        this.tersedia = new SimpleBooleanProperty(tersedia);
    }

    // --- Property Getters (Wajib untuk TableView) ---
    
    public IntegerProperty idProperty() { 
        return id_kendaraan; 
    }

    public StringProperty namaProperty() { 
        return nama; 
    }

    public StringProperty tipeProperty() { 
        return tipe; 
    }

    public StringProperty platProperty() { 
        return platNomor; 
    }

    public DoubleProperty hargaProperty() { 
        return hargaPerHari; 
    }

    public BooleanProperty tersediaProperty() { 
        return tersedia; 
    }

    // --- Regular Getters & Setters ---

    public int getId() { return id_kendaraan.get(); }
    
    public String getNama() { return nama.get(); }
    
    public String getTipe() { return tipe.get(); }
    
    public String getPlatNomor() { return platNomor.get(); }
    
    public double getHargaPerHari() { return hargaPerHari.get(); }
    
    public boolean isTersedia() { return tersedia.get(); }

    // Metode sesuai rancangan awal untuk memperbarui status
    public void ubahStatus(boolean status) { 
        this.tersedia.set(status); 
    }
}