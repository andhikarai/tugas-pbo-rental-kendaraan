package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class KendaraanDAO {

    // --- CREATE (Tambah Data) ---
    public static void tambahKendaraan(Kendaraan k) throws SQLException {
        // Menggunakan k.isTersedia() agar fleksibel
        String sql = "INSERT INTO kendaraan (nama, tipe, platNomor, hargaPerHari, tersedia) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, k.getNama());
            pstmt.setString(2, k.getTipe());
            pstmt.setString(3, k.getPlatNomor());
            pstmt.setDouble(4, k.getHargaPerHari());
            pstmt.setBoolean(5, k.isTersedia()); 
            
            pstmt.executeUpdate();
        }
    }

    // --- UPDATE (Edit Data) ---
    public static void updateKendaraan(Kendaraan k) throws SQLException {
        // Status tidak ikut di-update di sini agar tidak mereset status sewa
        String sql = "UPDATE kendaraan SET nama=?, tipe=?, platNomor=?, hargaPerHari=? WHERE id_kendaraan=?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, k.getNama());
            pstmt.setString(2, k.getTipe());
            pstmt.setString(3, k.getPlatNomor());
            pstmt.setDouble(4, k.getHargaPerHari());
            pstmt.setInt(5, k.getId());
            
            pstmt.executeUpdate();
        }
    }

    // --- DELETE (Hapus Data) ---
    public static void hapusKendaraan(int id) throws SQLException {
        String sql = "DELETE FROM kendaraan WHERE id_kendaraan=?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    // --- READ (Ambil Semua Data) ---
    public static ObservableList<Kendaraan> getAllKendaraan() {
        ObservableList<Kendaraan> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM kendaraan";
        
        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                list.add(new Kendaraan(
                    rs.getInt("id_kendaraan"),
                    rs.getString("nama"),
                    rs.getString("tipe"),
                    rs.getString("platNomor"),
                    rs.getDouble("hargaPerHari"),
                    rs.getBoolean("tersedia")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- STATISTIK (Wajib untuk Dashboard Admin) ---
    
    public static int getJumlahTotal() {
        return hitungData("SELECT COUNT(*) FROM kendaraan");
    }

    public static int getJumlahMobil() {
        return hitungData("SELECT COUNT(*) FROM kendaraan WHERE tipe = 'Mobil'");
    }

    public static int getJumlahMotor() {
        return hitungData("SELECT COUNT(*) FROM kendaraan WHERE tipe = 'Motor'");
    }

    // Metode bantuan private agar tidak menulis try-catch berulang-ulang
    private static int hitungData(String sql) {
        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // --- KHUSUS USER: Ambil Hanya Kendaraan yang TERSEDIA ---
    public static ObservableList<Kendaraan> getKendaraanTersedia() {
        ObservableList<Kendaraan> list = FXCollections.observableArrayList();
        // Filter hanya yang tersedia = 1
        String sql = "SELECT * FROM kendaraan WHERE tersedia = 1"; 
        
        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                list.add(new Kendaraan(
                    rs.getInt("id_kendaraan"),
                    rs.getString("nama"),
                    rs.getString("tipe"),
                    rs.getString("platNomor"),
                    rs.getDouble("hargaPerHari"),
                    rs.getBoolean("tersedia")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- KHUSUS USER: Proses Sewa (Ubah Status jadi FALSE/0) ---
    public static void sewaKendaraan(int id) throws SQLException {
        String sql = "UPDATE kendaraan SET tersedia = 0 WHERE id_kendaraan = ?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}