package com.login;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField userField;

    @FXML
    private PasswordField passField;

    @FXML
    private Label statusLabel;

    @FXML
    private void handleLogin() throws IOException {
        String username = userField.getText();
        String password = passField.getText();

        // 1. Validasi Input Kosong
        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Harap isi semua kolom!");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        // 2. Cek Login via DAO
        if (UserDAO.validateLogin(username, password)) {
            
            // 3. Ambil Data User & Simpan ke Session
            int userId = UserDAO.getUserId(username);
            String role = UserDAO.getUserRole(username);
            
            // Simpan sesi agar bisa dipakai di halaman berikutnya (untuk transaksi)
            UserSession.setSession(userId, role);

            // 4. Arahkan Halaman Sesuai Role
            if (role != null) {
                if (role.equalsIgnoreCase("admin")) {
                    App.setRoot("admin_dashboard");
                } else if (role.equalsIgnoreCase("penyewa")) {
                    App.setRoot("secondary"); // Halaman User/Penyewa
                } else {
                    statusLabel.setText("Role user tidak dikenali!");
                }
            } else {
                statusLabel.setText("Gagal mengambil role user!");
            }
            
        } else {
            statusLabel.setText("Username atau Password salah!");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }

    @FXML
    private void handleGoToRegister() throws IOException {
        App.setRoot("register");
    }
}