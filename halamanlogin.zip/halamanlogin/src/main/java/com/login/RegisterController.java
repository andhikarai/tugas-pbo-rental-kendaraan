package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterController {
    // Pastikan fx:id di register.fxml sama dengan nama variabel ini
    @FXML private TextField txtUsername, txtEmail, txtAlamat, txtNoTelp;
    @FXML private PasswordField txtPass;
    @FXML private Label lblStatus;

    @FXML
    private void handleRegister() {
        // Sesuaikan dengan Rancangan Sistem (Tabel Pengguna)
        String sql = "INSERT INTO user (Username, Password, email, Alamat, no_Telepon, Level_User) VALUES (?, ?, ?, ?, ?, 'Penyewa')";
        
        try (Connection conn = Database.connect(); // Pastikan kelas Database.java sudah benar
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, txtUsername.getText());
            pstmt.setString(2, txtPass.getText());
            pstmt.setString(3, txtEmail.getText());
            pstmt.setString(4, txtAlamat.getText());
            pstmt.setString(5, txtNoTelp.getText());
            
            pstmt.executeUpdate();
            lblStatus.setText("Registrasi Berhasil!");
        } catch (SQLException e) {
            lblStatus.setText("Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackToLogin() throws IOException {
        App.setRoot("primary");
    }
}