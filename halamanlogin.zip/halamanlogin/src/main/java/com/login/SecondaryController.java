package com.login;

// --- BAGIAN IMPORT (HARUS DI PALING ATAS) ---
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader; // Penting untuk buka form sewa
import javafx.scene.Parent;      // Penting
import javafx.scene.Scene;       // Penting
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;    // Penting
import javafx.stage.Stage;       // Penting
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

public class SecondaryController {

    @FXML private TextField txtSearch;
    @FXML private TableView<Kendaraan> tableUser;
    @FXML private TableColumn<Kendaraan, String> colNama, colTipe, colPlat;
    @FXML private TableColumn<Kendaraan, Double> colHarga;

    private ObservableList<Kendaraan> masterData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // 1. Setup Kolom Tabel
        colNama.setCellValueFactory(cellData -> cellData.getValue().namaProperty());
        colTipe.setCellValueFactory(cellData -> cellData.getValue().tipeProperty());
        colPlat.setCellValueFactory(cellData -> cellData.getValue().platProperty());
        
        // Format Rupiah
        colHarga.setCellValueFactory(cellData -> cellData.getValue().hargaProperty().asObject());
        colHarga.setCellFactory(tc -> new TableCell<Kendaraan, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) setText(null);
                else {
                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
                    setText(format.format(price));
                }
            }
        });

        // 2. Load Data Awal
        loadAvailableCars();

        // 3. Logika Filter Pencarian
        FilteredList<Kendaraan> filteredData = new FilteredList<>(masterData, p -> true);
        txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(kendaraan -> {
                if (newValue == null || newValue.isEmpty()) return true;
                String lowerCaseFilter = newValue.toLowerCase();
                if (kendaraan.getNama().toLowerCase().contains(lowerCaseFilter)) return true;
                else if (kendaraan.getTipe().toLowerCase().contains(lowerCaseFilter)) return true;
                else if (kendaraan.getPlatNomor().toLowerCase().contains(lowerCaseFilter)) return true;
                return false;
            });
        });

        SortedList<Kendaraan> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(tableUser.comparatorProperty());
        tableUser.setItems(sortedData);
    }

    private void loadAvailableCars() {
        ObservableList<Kendaraan> dataDB = KendaraanDAO.getKendaraanTersedia();
        masterData.clear();
        masterData.addAll(dataDB);
    }

    // --- BAGIAN HANDLER TOMBOL ---

    @FXML
    private void handleSewa() {
        Kendaraan selected = tableUser.getSelectionModel().getSelectedItem();

        if (selected == null) {
            showAlert(AlertType.WARNING, "Pilih Kendaraan", "Silakan klik salah satu kendaraan di tabel untuk menyewa.");
            return;
        }

        try {
            // Buka Pop-up Form Sewa (Pastikan file sewa_form.fxml sudah dibuat)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("sewa_form.fxml"));
            Parent root = loader.load();

            // Kirim data kendaraan ke Controller Form
            SewaFormController controller = loader.getController();
            controller.setKendaraan(selected);

            Stage stage = new Stage();
            stage.setTitle("Detail Sewa");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL); // Block window belakang
            stage.showAndWait();

            // Refresh tabel setelah form ditutup (agar mobil yg disewa hilang)
            loadAvailableCars();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Gagal membuka form sewa: " + e.getMessage());
        }
    }

    @FXML
    private void handleToRiwayat() throws IOException {
        App.setRoot("riwayat_sewa");
    }

    @FXML
    private void handleLogout() throws IOException {
        UserSession.clearSession(); // Bersihkan sesi saat logout
        App.setRoot("primary");
    }

    private void showAlert(AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}