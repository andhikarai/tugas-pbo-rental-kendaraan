package com.login;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.text.NumberFormat;
import java.util.Locale;

public class SewaFormController {

    @FXML private Label lblNamaKendaraan;
    @FXML private Label lblHargaPerHari;
    @FXML private DatePicker dpMulai;
    @FXML private DatePicker dpSelesai;
    @FXML private Label lblLamaSewa;
    @FXML private Label lblTotalBiaya;

    private Kendaraan kendaraan;
    private long totalBiayaHitungan = 0;
    private int lamaHari = 0;

    @FXML
    public void initialize() {
        // Listener: Jika tanggal berubah, hitung ulang biaya
        dpMulai.valueProperty().addListener((obs, oldVal, newVal) -> hitungBiaya());
        dpSelesai.valueProperty().addListener((obs, oldVal, newVal) -> hitungBiaya());
    }

    public void setKendaraan(Kendaraan k) {
        this.kendaraan = k;
        lblNamaKendaraan.setText(k.getNama() + " (" + k.getPlatNomor() + ")");
        
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
        lblHargaPerHari.setText(format.format(k.getHargaPerHari()) + " / hari");
    }

    private void hitungBiaya() {
        if (dpMulai.getValue() != null && dpSelesai.getValue() != null) {
            LocalDate start = dpMulai.getValue();
            LocalDate end = dpSelesai.getValue();

            // Hitung selisih hari
            long days = ChronoUnit.DAYS.between(start, end);

            if (days < 1) {
                lblLamaSewa.setText("Tanggal tidak valid!");
                lblTotalBiaya.setText("-");
                lamaHari = 0;
            } else {
                lamaHari = (int) days;
                lblLamaSewa.setText(lamaHari + " Hari");
                
                // Hitung Total
                totalBiayaHitungan = (long) (lamaHari * kendaraan.getHargaPerHari());
                
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));
                lblTotalBiaya.setText(format.format(totalBiayaHitungan));
            }
        }
    }

    @FXML
    private void handleConfirm() {
        if (lamaHari <= 0 || totalBiayaHitungan <= 0) {
            showAlert("Error", "Tanggal sewa tidak valid! Minimal 1 hari.");
            return;
        }

        try {
            // 1. Ambil ID User dari Session
            int idUser = UserSession.getUserId();
            
            // 2. Simpan ke Tabel Transaksi
            TransaksiDAO.buatTransaksi(
                idUser, 
                kendaraan.getId(), 
                dpMulai.getValue(), 
                dpSelesai.getValue(), 
                totalBiayaHitungan, 
                lamaHari
            );

            // 3. Update Status Kendaraan jadi Tidak Tersedia (0)
            KendaraanDAO.sewaKendaraan(kendaraan.getId());

            showAlert("Sukses", "Transaksi berhasil! Menunggu pengembalian.");
            closeWindow();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Gagal", "Error database: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void closeWindow() {
        Stage stage = (Stage) lblNamaKendaraan.getScene().getWindow();
        stage.close();
    }
}