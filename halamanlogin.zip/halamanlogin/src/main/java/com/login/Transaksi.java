package com.login;

import javafx.beans.property.*;
import java.time.LocalDate;

public class Transaksi {
    private final IntegerProperty idTransaksi;
    private final ObjectProperty<LocalDate> tanggalMulai;
    private final ObjectProperty<LocalDate> tanggalSelesai;
    private final IntegerProperty lamaSewa;
    private final DoubleProperty totalBiaya;
    private final StringProperty status;

    public Transaksi(int id, LocalDate mulai, LocalDate selesai, int lama, double total, String status) {
        this.idTransaksi = new SimpleIntegerProperty(id);
        this.tanggalMulai = new SimpleObjectProperty<>(mulai);
        this.tanggalSelesai = new SimpleObjectProperty<>(selesai);
        this.lamaSewa = new SimpleIntegerProperty(lama);
        this.totalBiaya = new SimpleDoubleProperty(total);
        this.status = new SimpleStringProperty(status);
    }

    // Property Getters untuk TableView
    public IntegerProperty idTransaksiProperty() { return idTransaksi; }
    public ObjectProperty<LocalDate> tanggalMulaiProperty() { return tanggalMulai; }
    public ObjectProperty<LocalDate> tanggalSelesaiProperty() { return tanggalSelesai; }
    public IntegerProperty lamaSewaProperty() { return lamaSewa; }
    public DoubleProperty totalBiayaProperty() { return totalBiaya; }
    public StringProperty statusProperty() { return status; }
}