package com.login;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.temporal.ChronoUnit;
import java.io.IOException;

public class TransaksiController {
    @FXML private DatePicker dpMulai, dpSelesai;
    @FXML private TextField txtLamaSewa, txtTotalBiaya;
    @FXML private TableView<Transaksi> tableTransaksi;
    
    private double hargaPerHari = 500000; // Contoh harga flat, nanti bisa diambil dari database

    @FXML
    private void hitungTotalBiaya() {
        if (dpMulai.getValue() != null && dpSelesai.getValue() != null) {
            long lama = ChronoUnit.DAYS.between(dpMulai.getValue(), dpSelesai.getValue());
            if (lama < 0) {
                txtLamaSewa.setText("Error");
                txtTotalBiaya.setText("0");
            } else {
                txtLamaSewa.setText(String.valueOf(lama));
                txtTotalBiaya.setText(String.valueOf(lama * hargaPerHari));
            }
        }
    }

    @FXML
    private void konfirmasiPesanan() {
        System.out.println("Pesanan dikonfirmasi ke database...");
        // Tambahkan logic INSERT INTO transaksi ke MySQL di sini
    }

    @FXML
    private void selesaikanTransaksi() {
        System.out.println("Status diperbarui menjadi Selesai...");
        // Tambahkan logic UPDATE status transaksi ke MySQL di sini
    }

    @FXML
    private void handleBack() throws IOException {
        App.setRoot("admin_dashboard");
    }
}