package com.login;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; // <--- INI YANG HILANG SEBELUMNYA
import java.time.LocalDate;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class TransaksiDAO {

    // --- USER: Simpan Data Transaksi Baru ---
    public static void buatTransaksi(int idPenyewa, int idKendaraan, LocalDate tglMulai, LocalDate tglSelesai, long totalBiaya, int lamaSewa) throws SQLException {
        String sql = "INSERT INTO transaksi (tglMulai, tglSelesai, totalBiaya, lamaSewa, ID_Penyewa, ID_Kendaraan) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, Date.valueOf(tglMulai));
            pstmt.setDate(2, Date.valueOf(tglSelesai));
            pstmt.setBigDecimal(3, java.math.BigDecimal.valueOf(totalBiaya));
            pstmt.setInt(4, lamaSewa);
            pstmt.setInt(5, idPenyewa);
            pstmt.setInt(6, idKendaraan);
            
            pstmt.executeUpdate();
        }
    }

    // --- ADMIN: Ambil Data Transaksi yang Sedang Berjalan (Status Mobil 0) ---
    public static ObservableList<TransaksiView> getTransaksiAktif() {
        ObservableList<TransaksiView> list = FXCollections.observableArrayList();
        
        // Query Join 3 Tabel: Transaksi, User, Kendaraan
        String sql = "SELECT t.ID_Transaksi, u.Username, k.nama, k.platNomor, t.tglMulai, t.tglSelesai, k.id_kendaraan " +
                     "FROM transaksi t " +
                     "JOIN user u ON t.ID_Penyewa = u.ID_User " +
                     "JOIN kendaraan k ON t.ID_Kendaraan = k.id_kendaraan " +
                     "WHERE k.tersedia = 0 " + 
                     "ORDER BY t.tglSelesai ASC";

        try (Connection conn = Database.connect();
             Statement stmt = conn.createStatement(); // Menggunakan Statement di sini
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                list.add(new TransaksiView(
                    rs.getInt("ID_Transaksi"),
                    rs.getString("Username"),
                    rs.getString("nama"),
                    rs.getString("platNomor"),
                    rs.getDate("tglMulai"),
                    rs.getDate("tglSelesai"),
                    rs.getInt("id_kendaraan")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // --- ADMIN: Proses Pengembalian (Update Status Mobil jadi 1) ---
    public static void terimaPengembalian(int idKendaraan) throws SQLException {
        String sql = "UPDATE kendaraan SET tersedia = 1 WHERE id_kendaraan = ?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, idKendaraan);
            pstmt.executeUpdate();
        }
    }
}