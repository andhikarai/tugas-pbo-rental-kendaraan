package com.login;

import java.sql.Date;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class TransaksiView {
    private final IntegerProperty idTransaksi;
    private final StringProperty namaPenyewa;
    private final StringProperty namaKendaraan;
    private final StringProperty platNomor;
    private final StringProperty tglMulai;
    private final StringProperty tglSelesai;
    private final IntegerProperty idKendaraan; // Disimpan untuk proses update status nanti

    public TransaksiView(int idTrans, String user, String mobil, String plat, Date mulai, Date selesai, int idMobil) {
        this.idTransaksi = new SimpleIntegerProperty(idTrans);
        this.namaPenyewa = new SimpleStringProperty(user);
        this.namaKendaraan = new SimpleStringProperty(mobil);
        this.platNomor = new SimpleStringProperty(plat);
        this.tglMulai = new SimpleStringProperty(mulai.toString());
        this.tglSelesai = new SimpleStringProperty(selesai.toString());
        this.idKendaraan = new SimpleIntegerProperty(idMobil);
    }

    // Getters untuk Property (Wajib untuk TableView)
    public IntegerProperty idTransaksiProperty() { return idTransaksi; }
    public StringProperty namaPenyewaProperty() { return namaPenyewa; }
    public StringProperty namaKendaraanProperty() { return namaKendaraan; }
    public StringProperty platNomorProperty() { return platNomor; }
    public StringProperty tglMulaiProperty() { return tglMulai; }
    public StringProperty tglSelesaiProperty() { return tglSelesai; }
    
    public int getIdKendaraan() { return idKendaraan.get(); }
    public String getNamaPenyewa() { return namaPenyewa.get(); }
    public String getNamaKendaraan() { return namaKendaraan.get(); }
}