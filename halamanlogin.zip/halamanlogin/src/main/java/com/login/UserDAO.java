package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    // Cek apakah username & password cocok
    public static boolean validateLogin(String username, String password) {
        String query = "SELECT * FROM user WHERE Username = ? AND Password = ?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // True jika user ditemukan
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Ambil role (Admin/Penyewa) berdasarkan username
    public static String getUserRole(String username) {
        String query = "SELECT Level_User FROM user WHERE Username = ?";
        
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
             
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getString("Level_User");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Tambahkan ini di dalam class UserDAO
    public static int getUserId(String username) {
        String query = "SELECT ID_User FROM user WHERE Username = ?";
        try (Connection conn = Database.connect();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("ID_User");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; // Return 0 jika user tidak ditemukan
    }
}