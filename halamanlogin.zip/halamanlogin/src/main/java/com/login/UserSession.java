package com.login;

public class UserSession {
    private static int userId;
    private static String userRole;

    public static void setSession(int id, String role) {
        userId = id;
        userRole = role;
    }

    public static int getUserId() {
        return userId;
    }

    public static String getUserRole() {
        return userRole;
    }

    public static void clearSession() {
        userId = 0;
        userRole = null;
    }
}