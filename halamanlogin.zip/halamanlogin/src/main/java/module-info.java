module com.login {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; 

    opens com.login to javafx.fxml;
    exports com.login;
}